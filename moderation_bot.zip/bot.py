import discord
from discord.ext import commands
import os

TOKEN = os.getenv("TOKEN")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

ALLOWED_USERS = ["drhandle", "itsbielzinn"]

def is_allowed(ctx):
    return ctx.author.name in ALLOWED_USERS

@bot.event
async def on_ready():
    await bot.change_presence(activity=discord.Game(name="Moderating Server"))
    print(f"Logged in as {bot.user}")

@bot.command()
@commands.check(is_allowed)
async def kick(ctx, member: discord.Member, *, reason=None):
    await member.kick(reason=reason)
    await ctx.send(f"Kicked {member.mention}")

@bot.command()
@commands.check(is_allowed)
async def ban(ctx, member: discord.Member, *, reason=None):
    await member.ban(reason=reason)
    await ctx.send(f"Banned {member.mention}")

@bot.command()
@commands.check(is_allowed)
async def unban(ctx, *, user_name):
    banned_users = await ctx.guild.bans()
    for ban_entry in banned_users:
        user = ban_entry.user
        if user.name == user_name:
            await ctx.guild.unban(user)
            await ctx.send(f"Unbanned {user_name}")
            return
    await ctx.send(f"User {user_name} not found in ban list.")

@bot.command()
@commands.check(is_allowed)
async def clear(ctx, amount: int):
    await ctx.channel.purge(limit=amount + 1)
    await ctx.send(f"Cleared {amount} messages", delete_after=5)

@bot.command()
@commands.check(is_allowed)
async def warn(ctx, member: discord.Member, *, reason="No reason provided"):
    await ctx.send(f"{member.mention}, you have been warned for: {reason}")

bot.run(TOKEN)
