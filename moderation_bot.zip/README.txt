# Moderation Bot

## Features
- Commands: !kick, !ban, !unban, !warn, !clear
- Only "drhandle" and "itsbielzinn" can use these commands.
- Shows "Moderating Server" as bot status.

## Setup & Hosting (Free with Render)
1. Create a new **Discord Bot Token** in the Discord Developer Portal.
2. Put your token as an environment variable in Render:
   - Key: TOKEN
   - Value: your_token_here

3. Upload these files to a GitHub repo (or directly in Render).
4. In Render:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python bot.py`

Your bot will now run 24/7 for free!
